import { Request, Response } from "express";
import app from "./app";

// classe - Forma do meu sistema
export class Usuario{
    // atributos sao informacoes da classe
    private nome:string;
    private idade:number;  
    private cpf:string;

    // metodo da classe
    constructor(nome:string,idade:number,cpf:string){
       this.nome = nome;
       this.idade = idade
       this.cpf = cpf
       this.verificar(nome,idade,cpf)
    }

    // metodo da classe
    private verificar(nome:string,idade:number,cpf:string){
        if(!nome || !idade || !cpf){
            throw new Error("Dados devem ser preenchidos")
        }
    }
    // informacao do nome
    getNome(){
        return this.nome
    }

    setNome(nome:string){
        this.nome = nome
    }

}

app.post("/inserirNoBanco",(req:Request , res:Response)=>{
    try {
       const {nome,idade,cpf} = req.body
 
       const usuario = new Usuario(nome,idade,cpf)
      
 
    } catch (error:any) {
       res.status(500).send({message:error.message})
    }
 })

// instanciar a minha classe
// Chamar a funcao é a mesma ideia de instanciar uma classe





// class Animal{

//     private nome:string;
//     private tipo:string;
//     private raca:string;

//     //metodo da classe
//     constructor(nome:string,tipo:string,raca:string){
//         this.nome = nome
//         this.tipo = tipo
//         this.raca = raca
//     }

//     private som(tipo:string){
//         if(tipo === "cachorro"){
//             console.log("AU AU !")
//         }
//         if(tipo === "gato"){
//             console.log("MIAU !")
//         } 
//     }

//     getNome(){
//         return this.nome
//     }
// }

// // instanciando a minha classe
// const animal = new Animal("dino","cachorro","caramelo")


// console.log(animal.getNome())









